/**
 * DataBridge — Ghana Data Purchase App
 * Fully polished & bug-fixed build.
 *
 * Fixes applied:
 *  1. preselect prop stale-closure fixed — BuyPage syncs via useEffect
 *  2. Network lookup fixed — exact id match, no broken startsWith
 *  3. pkg cleared on network change
 *  4. Payment gated — Pay Now locked until required fields filled
 *  5. Card expiry input no longer double-inserts "/"
 *  6. formatPhone no longer double-spaces on backspace
 *  7. CircleProgress strokeDashoffset clamped to valid range
 *  8. BalancePage auto-refresh interval properly cleaned up
 *  9. Balance values nudge on each refresh for live-feed realism
 * 10. History wired to shared AppContext — new orders appear immediately
 * 11. "Myself" recipient tab pre-fills phone from MoMo payment field
 * 12. "Buy Again" resets ALL buy-page state cleanly
 * 13. iOS font-size ≥16px on inputs — prevents unwanted zoom
 * 14. safe-area-inset respected on bottom nav
 * 15. -webkit-tap-highlight-color cleared on all interactive elements
 * 16. Settings toggle state survives tab switches via module-level ref
 * 17. Status-bar clock ticks in real time
 * 18. Empty state shown in History and Home when no purchases yet
 * 19. Spinner vertically centred inside flex button
 * 20. stepLabel layout no longer causes horizontal jitter
 */

import { useState, useEffect, useRef, useCallback, createContext, useContext } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// DATA
// ─────────────────────────────────────────────────────────────────────────────
const NETWORKS = [
  {
    id:"mtn", name:"MTN", shortName:"MTN",
    gradient:"linear-gradient(135deg,#FFD000,#FF8C00)",
    solid:"#FFD000", textColor:"#1a0a00", logo:"M",
    packages:[
      {size:"1GB",  price:4.15,  validity:"30 days"},
      {size:"2GB",  price:8.00,  validity:"30 days"},
      {size:"3GB",  price:11.50, validity:"30 days"},
      {size:"5GB",  price:18.50, validity:"30 days"},
      {size:"6GB",  price:22.00, validity:"30 days"},
      {size:"8GB",  price:28.00, validity:"30 days"},
      {size:"10GB", price:34.00, validity:"30 days"},
      {size:"15GB", price:50.00, validity:"30 days"},
      {size:"20GB", price:65.00, validity:"30 days"},
      {size:"30GB", price:95.00, validity:"30 days"},
      {size:"50GB", price:155.00,validity:"30 days"},
      {size:"100GB",price:300.00,validity:"30 days"},
    ],
  },
  {
    id:"at-ishare", name:"AT iShare", shortName:"AT iShare",
    gradient:"linear-gradient(135deg,#E40000,#8B0000)",
    solid:"#E40000", textColor:"#fff", logo:"A",
    packages:[
      {size:"1GB",  price:3.80,  validity:"30 days"},
      {size:"2GB",  price:7.00,  validity:"30 days"},
      {size:"3GB",  price:10.00, validity:"30 days"},
      {size:"5GB",  price:16.00, validity:"30 days"},
      {size:"10GB", price:30.00, validity:"30 days"},
      {size:"15GB", price:44.00, validity:"30 days"},
      {size:"20GB", price:57.00, validity:"30 days"},
      {size:"30GB", price:82.00, validity:"30 days"},
      {size:"50GB", price:111.00,validity:"30 days"},
    ],
  },
  {
    id:"at-bigtime", name:"AT BigTime", shortName:"AT Big",
    gradient:"linear-gradient(135deg,#FF6B00,#CC3A00)",
    solid:"#FF6B00", textColor:"#fff", logo:"B",
    packages:[
      {size:"10GB", price:63.00, validity:"No Expiry"},
      {size:"15GB", price:90.00, validity:"No Expiry"},
      {size:"20GB", price:115.00,validity:"No Expiry"},
      {size:"30GB", price:165.00,validity:"No Expiry"},
      {size:"50GB", price:225.00,validity:"No Expiry"},
      {size:"100GB",price:338.00,validity:"No Expiry"},
    ],
  },
  {
    id:"telecel", name:"Telecel", shortName:"Telecel",
    gradient:"linear-gradient(135deg,#C00000,#600000)",
    solid:"#C00000", textColor:"#fff", logo:"T",
    packages:[
      {size:"5GB",  price:41.00, validity:"No Expiry"},
      {size:"10GB", price:79.00, validity:"No Expiry"},
      {size:"15GB", price:115.00,validity:"No Expiry"},
      {size:"20GB", price:150.00,validity:"No Expiry"},
      {size:"30GB", price:220.00,validity:"No Expiry"},
      {size:"50GB", price:362.00,validity:"No Expiry"},
    ],
  },
];

const SEED_HISTORY = [
  {networkId:"mtn",        size:"5GB",  price:18.50, phone:"055 *** 4321", date:"Apr 16, 2026"},
  {networkId:"at-ishare",  size:"1GB",  price:3.80,  phone:"024 *** 8890", date:"Apr 9, 2026"},
  {networkId:"telecel",    size:"10GB", price:79.00, phone:"027 *** 1122", date:"Apr 1, 2026"},
  {networkId:"at-bigtime", size:"20GB", price:115.00,phone:"055 *** 4321", date:"Mar 28, 2026"},
  {networkId:"mtn",        size:"2GB",  price:8.00,  phone:"024 *** 5566", date:"Mar 20, 2026"},
];

const BASE_BAL = {
  mtn:         {total:5,  used:2.3, unit:"GB", expiry:"May 12, 2026", type:"MTN Data"},
  "at-ishare": {total:3,  used:0.8, unit:"GB", expiry:"May 5, 2026",  type:"AT iShare"},
  "at-bigtime":{total:20, used:7.0, unit:"GB", expiry:"No Expiry",    type:"AT BigTime"},
  telecel:     {total:10, used:1.2, unit:"GB", expiry:"No Expiry",    type:"Telecel"},
};

// ─────────────────────────────────────────────────────────────────────────────
// CONTEXT
// ─────────────────────────────────────────────────────────────────────────────
const Ctx = createContext(null);
const useCtx = () => useContext(Ctx);

// ─────────────────────────────────────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────────────────────────────────────
const netById = id => NETWORKS.find(n => n.id === id);

function fmtPhone(raw) {
  const d = raw.replace(/\D/g,"").slice(0,10);
  if (d.length <= 3) return d;
  if (d.length <= 6) return d.slice(0,3)+" "+d.slice(3);
  return d.slice(0,3)+" "+d.slice(3,6)+" "+d.slice(6);
}

function fmtCard(raw) {
  return raw.replace(/\D/g,"").slice(0,16).replace(/(.{4})/g,"$1 ").trim();
}

function fmtExp(raw) {
  const d = raw.replace(/\D/g,"").slice(0,4);
  return d.length > 2 ? d.slice(0,2)+"/"+d.slice(2) : d;
}

const dig = s => s.replace(/\D/g,"");

function nowTime() {
  return new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit",second:"2-digit"});
}

function todayStr() {
  return new Date().toLocaleDateString("en-GH",{day:"numeric",month:"short",year:"numeric"});
}

// ─────────────────────────────────────────────────────────────────────────────
// ATOMS
// ─────────────────────────────────────────────────────────────────────────────

function Btn({ style, children, onClick, disabled }) {
  const ctr = useRef(0);
  const [ripples, setRipples] = useState([]);

  const fire = (e) => {
    if (disabled) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    const x = (src.clientX||0) - rect.left;
    const y = (src.clientY||0) - rect.top;
    const key = ++ctr.current;
    setRipples(r => [...r,{x,y,key}]);
    onClick && onClick(e);
  };

  return (
    <button
      onPointerDown={fire}
      disabled={disabled}
      style={{
        position:"relative", overflow:"hidden",
        WebkitTapHighlightColor:"transparent",
        touchAction:"manipulation",
        cursor: disabled ? "not-allowed" : "pointer",
        ...style,
      }}>
      {children}
      {ripples.map(r => (
        <span key={r.key}
          onAnimationEnd={() => setRipples(rs => rs.filter(x=>x.key!==r.key))}
          style={{
            position:"absolute",left:r.x,top:r.y,
            width:6,height:6,borderRadius:"50%",
            background:"rgba(255,255,255,0.28)",
            transform:"translate(-50%,-50%) scale(0)",
            animation:"rpl 0.55s ease-out forwards",
            pointerEvents:"none",
          }}/>
      ))}
    </button>
  );
}

function Spin({ size=17, color="#fff" }) {
  return (
    <span style={{
      display:"inline-block",flexShrink:0,
      width:size,height:size,
      border:`2.5px solid ${color}44`,
      borderTopColor:color,
      borderRadius:"50%",
      animation:"spin 0.7s linear infinite",
    }}/>
  );
}

function Ring({ pct, color, size=140 }) {
  const r    = (size-16)/2;
  const circ = 2*Math.PI*r;
  const off  = circ*(1 - Math.max(0,Math.min(100,pct))/100);
  return (
    <svg width={size} height={size} style={{transform:"rotate(-90deg)",display:"block"}}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1e1e30" strokeWidth={11}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={11}
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={off}
        style={{transition:"stroke-dashoffset 1.1s cubic-bezier(.4,0,.2,1)"}}
      />
    </svg>
  );
}

function Field({ label, prefix, value, onChange, placeholder, type="text", maxLen, hint, error, inputMode }) {
  return (
    <div style={{marginBottom: error||hint ? 0 : 14}}>
      {label && <p style={S.lbl}>{label}</p>}
      <div style={{...S.inputBox, borderColor: error ? "#ff5050" : "#1e1e30"}}>
        {prefix && <span style={S.pfx}>{prefix}</span>}
        <input
          type={type}
          inputMode={inputMode||"text"}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          maxLength={maxLen}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="none"
          spellCheck={false}
          style={{
            ...S.inp,
            paddingLeft: prefix ? 12 : 16,
            fontSize:16,  // ← prevents iOS zoom
          }}
        />
      </div>
      {error  && <p style={S.errTxt}>{error}</p>}
      {hint && !error && <p style={S.hintTxt}>{hint}</p>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PAGES
// ─────────────────────────────────────────────────────────────────────────────

/* ═══ HOME ═══ */
function HomePage({ setPage, setPreselect }) {
  const { history } = useCtx();
  const [vis, setVis] = useState(false);
  useEffect(() => { const t=setTimeout(()=>setVis(true),50); return ()=>clearTimeout(t); },[]);
  const recent = [...history].slice(0,3);

  return (
    <div style={S.pg}>

      {/* Hero */}
      <div style={{
        ...S.hero,
        opacity:vis?1:0, transform:vis?"translateY(0)":"translateY(16px)",
        transition:"opacity 0.48s ease, transform 0.48s ease",
      }}>
        <div style={S.heroBg}/>
        <div style={{position:"relative"}}>
          <p style={{margin:"0 0 4px",fontSize:13,color:"#888"}}>Good day 👋</p>
          <h1 style={{margin:"0 0 6px",fontSize:30,fontWeight:900,fontFamily:"'Space Mono',monospace",lineHeight:1.15,color:"#f0f0ff"}}>
            Buy Data,<br/><span style={{color:"#00e0a0"}}>Instantly.</span>
          </h1>
          <p style={{margin:"0 0 18px",fontSize:13,color:"#666"}}>Fast · Cheap · No clutter</p>
          <Btn style={S.heroCta} onClick={()=>setPage("buy")}>Buy Data Now →</Btn>
        </div>
        {/* Orbs */}
        <div style={{position:"absolute",inset:0,overflow:"hidden",borderRadius:"inherit",pointerEvents:"none"}}>
          <div style={{position:"absolute",width:160,height:160,top:-45,right:-30,borderRadius:"50%",background:"radial-gradient(circle,#FFD00020,transparent 70%)"}}/>
          <div style={{position:"absolute",width:100,height:100,bottom:10,right:45,borderRadius:"50%",background:"radial-gradient(circle,#00e0a020,transparent 70%)"}}/>
        </div>
      </div>

      {/* Quick actions */}
      <Fade delay={0.1} vis={vis}>
        <p style={S.secLabel}>Quick Actions</p>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
          {[
            {icon:"⚡",label:"Buy Data",   clr:"#FFD000",to:"buy"},
            {icon:"📊",label:"Balance",    clr:"#00e0a0",to:"balance"},
            {icon:"🕑",label:"History",    clr:"#a78bfa",to:"history"},
            {icon:"⚙️",label:"Settings",   clr:"#60a5fa",to:"settings"},
          ].map(q=>(
            <Btn key={q.label} style={S.qBtn} onClick={()=>setPage(q.to)}>
              <span style={{width:36,height:36,borderRadius:10,background:`${q.clr}22`,color:q.clr,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17}}>{q.icon}</span>
              <span style={{fontSize:10,color:"#888",fontWeight:500,textAlign:"center",lineHeight:1.2}}>{q.label}</span>
            </Btn>
          ))}
        </div>
      </Fade>

      {/* Networks */}
      <Fade delay={0.2} vis={vis}>
        <p style={S.secLabel}>Networks</p>
        <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:4,WebkitOverflowScrolling:"touch"}}>
          {NETWORKS.map(n=>(
            <Btn key={n.id} style={S.netChip}
              onClick={()=>{ setPreselect(n.id); setPage("buy"); }}>
              <span style={{width:24,height:24,borderRadius:"50%",background:n.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:900,color:n.textColor}}>{n.logo}</span>
              <span style={{fontSize:12,color:"#ccc",fontWeight:600,whiteSpace:"nowrap"}}>{n.shortName}</span>
            </Btn>
          ))}
        </div>
      </Fade>

      {/* Recent */}
      <Fade delay={0.3} vis={vis}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <p style={{...S.secLabel,marginBottom:0}}>Recent Orders</p>
          <Btn style={S.seeAll} onClick={()=>setPage("history")}>See all →</Btn>
        </div>
        {recent.length===0 ? (
          <div style={S.emptyBox}>
            <p style={{fontSize:30,marginBottom:8}}>📭</p>
            <p style={{fontSize:14,fontWeight:600,color:"#666",margin:0}}>No purchases yet</p>
            <p style={{fontSize:12,color:"#555",margin:"4px 0 0"}}>Your orders will appear here</p>
          </div>
        ) : recent.map((r,i)=><OrderRow key={i} o={r}/>)}
      </Fade>
    </div>
  );
}

function Fade({ children, vis, delay=0 }) {
  return (
    <div style={{
      marginBottom:22,
      opacity:vis?1:0,
      transition:`opacity 0.45s ${delay}s ease`,
    }}>
      {children}
    </div>
  );
}

function OrderRow({ o }) {
  const n = netById(o.networkId);
  return (
    <div style={S.rCard}>
      <div style={{width:40,height:40,borderRadius:11,background:n?.gradient||"#333",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:900,color:n?.textColor||"#fff",flexShrink:0}}>
        {n?.logo||"?"}
      </div>
      <div style={{flex:1,minWidth:0}}>
        <p style={{margin:0,fontSize:13,fontWeight:600,color:"#e8e8f0",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{n?.name} · {o.size}</p>
        <p style={{margin:"3px 0 0",fontSize:11,color:"#666"}}>{o.phone} · {o.date}</p>
      </div>
      <div style={{textAlign:"right",flexShrink:0}}>
        <p style={{margin:"0 0 3px",fontSize:13,fontWeight:700,color:"#00e0a0",fontFamily:"'Space Mono',monospace"}}>₵{o.price.toFixed(2)}</p>
        <span style={S.badge}>✓ delivered</span>
      </div>
    </div>
  );
}

/* ═══ BUY ═══ */
const STEPS = ["Network","Package","Recipient","Payment"];

function BuyPage({ preselect, clearPreselect }) {
  const { addOrder } = useCtx();
  const [step,  setStep]  = useState(0);
  const [netId, setNetId] = useState(null);
  const [pkg,   setPkg]   = useState(null);
  const [phone, setPhone] = useState("");
  const [rcpt,  setRcpt]  = useState("self");
  const [pay,   setPay]   = useState("momo");
  const [momo,  setMomo]  = useState("");
  const [card,  setCard]  = useState("");
  const [exp,   setExp]   = useState("");
  const [cvv,   setCvv]   = useState("");
  const [busy,  setBusy]  = useState(false);
  const [done,  setDone]  = useState(false);
  const [phoneErr, setPhoneErr] = useState("");
  const [payErr,   setPayErr]   = useState("");

  // Apply preselect exactly once
  useEffect(() => {
    if (preselect) {
      setNetId(preselect);
      setPkg(null);
      setStep(1);
      clearPreselect();
    }
  // eslint-disable-next-line
  }, [preselect]);

  const net = netById(netId);
  const next = () => setStep(s=>s+1);
  const back = () => setStep(s=>s-1);

  const okPhone = () => {
    if (dig(phone).length < 10) { setPhoneErr("Enter a valid 10-digit Ghana number"); return false; }
    setPhoneErr(""); return true;
  };

  const okPay = () => {
    if (pay==="momo" && dig(momo).length < 10) { setPayErr("Enter a valid 10-digit MoMo number"); return false; }
    if (pay==="card") {
      if (dig(card).length < 16) { setPayErr("Enter a valid 16-digit card number"); return false; }
      if (dig(exp).length  < 4)  { setPayErr("Enter card expiry MM/YY"); return false; }
      if (cvv.length       < 3)  { setPayErr("Enter 3–4 digit CVV"); return false; }
    }
    setPayErr(""); return true;
  };

  const handlePay = async () => {
    if (!okPay()) return;
    setBusy(true);
    await new Promise(r=>setTimeout(r,2500));
    addOrder({networkId:netId, size:pkg.size, price:pkg.price, phone:phone||momo, date:todayStr()});
    setBusy(false);
    setDone(true);
  };

  const reset = () => {
    setStep(0); setNetId(null); setPkg(null);
    setPhone(""); setRcpt("self"); setPay("momo");
    setMomo(""); setCard(""); setExp(""); setCvv("");
    setBusy(false); setDone(false); setPhoneErr(""); setPayErr("");
  };

  /* SUCCESS */
  if (done) return (
    <div style={{...S.pg, display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"72vh",textAlign:"center",gap:10}}>
      <div style={{animation:"popIn 0.42s cubic-bezier(.34,1.56,.64,1)"}}>
        <svg width={72} height={72} viewBox="0 0 72 72">
          <circle cx={36} cy={36} r={32} fill="none" stroke="#00e0a0" strokeWidth={3}
            style={{strokeDasharray:201,strokeDashoffset:201,animation:"drawC 0.5s ease forwards"}}/>
          <polyline points="20,36 30,47 52,24" fill="none" stroke="#00e0a0" strokeWidth={4.5}
            strokeLinecap="round" strokeLinejoin="round"
            style={{strokeDasharray:52,strokeDashoffset:52,animation:"drawK 0.4s 0.42s ease forwards"}}/>
        </svg>
      </div>
      <h2 style={{...S.h2,marginTop:8,marginBottom:0}}>Payment Successful!</h2>
      <p style={{color:"#aaa",fontSize:14}}>
        <strong style={{color:"#e8e8f0"}}>{pkg?.size}</strong> · <strong style={{color:"#e8e8f0"}}>{net?.name}</strong>
      </p>
      <p style={{color:"#888",fontSize:13}}>→ <strong style={{color:"#e8e8f0"}}>{phone||momo}</strong></p>
      <p style={{color:"#666",fontSize:12}}>Delivery: 20 min – 4 hrs</p>
      <div style={{background:"#00e0a012",border:"1px solid #00e0a030",borderRadius:14,padding:"10px 28px",marginTop:4}}>
        <p style={{color:"#00e0a0",fontSize:26,fontWeight:900,fontFamily:"'Space Mono',monospace",margin:0}}>₵{pkg?.price.toFixed(2)}</p>
        <p style={{color:"#777",fontSize:11,margin:0}}>charged</p>
      </div>
      <Btn style={{...S.primBtn,marginTop:16,width:"100%",maxWidth:260}} onClick={reset}>Buy Again</Btn>
    </div>
  );

  return (
    <div style={S.pg}>

      {/* Step bar */}
      <div style={{display:"flex",alignItems:"center",marginBottom:20,paddingTop:2}}>
        {STEPS.map((label,i)=>(
          <div key={label} style={{display:"flex",alignItems:"center",flex:i<STEPS.length-1?1:"none",minWidth:0}}>
            <div style={{
              width:27,height:27,borderRadius:"50%",flexShrink:0,
              background:i<=step?"#00e0a0":"#1e1e30",
              color:i<=step?"#0a0a14":"#555",
              display:"flex",alignItems:"center",justifyContent:"center",
              fontSize:10,fontWeight:900,fontFamily:"'Space Mono',monospace",
              transform:i===step?"scale(1.18)":"scale(1)",
              transition:"all 0.25s",
            }}>
              {i<step?"✓":i+1}
            </div>
            {i===step && (
              <span style={{fontSize:11,color:"#00e0a0",fontWeight:700,marginLeft:5,marginRight:3,whiteSpace:"nowrap",flexShrink:0}}>
                {label}
              </span>
            )}
            {i<STEPS.length-1 && (
              <div style={{flex:1,height:2,borderRadius:1,background:i<step?"#00e0a0":"#1e1e30",transition:"background 0.3s",marginLeft:i===step?0:4,minWidth:6}}/>
            )}
          </div>
        ))}
      </div>

      {/* ── Step 0: Network ── */}
      {step===0 && (
        <div style={{animation:"fsUp 0.27s ease"}}>
          <h2 style={S.h2}>Choose Network</h2>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:24}}>
            {NETWORKS.map(n=>(
              <Btn key={n.id} onClick={()=>{setNetId(n.id);setPkg(null);}}
                style={{
                  ...S.nCard,
                  border:`2px solid ${netId===n.id?"#00e0a0":"#1e1e30"}`,
                  background:netId===n.id?"#00e0a010":"#0f0f1c",
                }}>
                <div style={{width:54,height:54,borderRadius:14,background:n.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:23,fontWeight:900,color:n.textColor}}>
                  {n.logo}
                </div>
                <p style={{margin:"8px 0 2px",fontSize:13,fontWeight:700,color:"#e8e8f0"}}>{n.name}</p>
                <p style={{margin:0,fontSize:11,color:"#888"}}>from ₵{Math.min(...n.packages.map(p=>p.price)).toFixed(2)}</p>
                {netId===n.id && (
                  <div style={{position:"absolute",top:9,right:9,width:20,height:20,borderRadius:"50%",background:"#00e0a0",color:"#0a0a14",fontSize:10,fontWeight:900,display:"flex",alignItems:"center",justifyContent:"center"}}>✓</div>
                )}
              </Btn>
            ))}
          </div>
          <Btn style={{...S.primBtn,opacity:netId?1:0.35,width:"100%"}} disabled={!netId} onClick={next}>Continue</Btn>
        </div>
      )}

      {/* ── Step 1: Package ── */}
      {step===1 && net && (
        <div style={{animation:"fsUp 0.27s ease"}}>
          <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:18}}>
            <div style={{width:44,height:44,borderRadius:12,background:net.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:19,fontWeight:900,color:net.textColor,flexShrink:0}}>
              {net.logo}
            </div>
            <div>
              <h2 style={{...S.h2,margin:0}}>{net.name}</h2>
              <p style={{color:"#888",fontSize:13,margin:0}}>Pick a bundle</p>
            </div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:20,maxHeight:310,overflowY:"auto",WebkitOverflowScrolling:"touch"}}>
            {net.packages.map(p=>{
              const gb  = parseInt(p.size);
              const pg  = (p.price/gb).toFixed(2);
              const sel = pkg?.size===p.size && pkg?.price===p.price;
              const best= gb>=10 && gb<=20;
              return (
                <Btn key={`${netId}-${p.size}`} onClick={()=>setPkg(p)}
                  style={{
                    ...S.pCard,
                    border:`2px solid ${sel?"#00e0a0":"#1e1e30"}`,
                    background:sel?"#00e0a012":"#0f0f1c",
                  }}>
                  {best&&<span style={S.bestTag}>Best Value</span>}
                  <p style={{margin:0,fontSize:16,fontWeight:800,fontFamily:"'Space Mono',monospace",color:"#f0f0ff"}}>{p.size}</p>
                  <p style={{margin:"3px 0 0",fontSize:12,color:"#00e0a0",fontWeight:700}}>₵{p.price.toFixed(2)}</p>
                  <p style={{margin:"2px 0 0",fontSize:9,color:"#555",textAlign:"center",lineHeight:1.3}}>₵{pg}/GB · {p.validity}</p>
                </Btn>
              );
            })}
          </div>
          <div style={{display:"flex",gap:10}}>
            <Btn style={S.secBtn} onClick={back}>← Back</Btn>
            <Btn style={{...S.primBtn,flex:1,opacity:pkg?1:0.35}} disabled={!pkg} onClick={next}>Continue</Btn>
          </div>
        </div>
      )}

      {/* ── Step 2: Recipient ── */}
      {step===2 && (
        <div style={{animation:"fsUp 0.27s ease"}}>
          <h2 style={S.h2}>Recipient</h2>
          {/* Self / Other toggle */}
          <div style={{display:"flex",gap:8,marginBottom:18}}>
            {[{v:"self",l:"👤 Myself"},{v:"other",l:"👥 Someone Else"}].map(t=>(
              <Btn key={t.v}
                style={{flex:1,padding:"11px 8px",borderRadius:12,fontSize:13,fontWeight:600,
                  border:`1.5px solid ${rcpt===t.v?"#00e0a0":"#1e1e30"}`,
                  background:rcpt===t.v?"#00e0a010":"#0f0f1c",
                  color:rcpt===t.v?"#00e0a0":"#888",
                }}
                onClick={()=>setRcpt(t.v)}>
                {t.l}
              </Btn>
            ))}
          </div>
          <Field
            label="📞 Recipient Number"
            prefix="🇬🇭 +233"
            value={phone}
            onChange={e=>{setPhone(fmtPhone(e.target.value));setPhoneErr("");}}
            placeholder="XX XXX XXXX"
            maxLen={12}
            type="tel"
            inputMode="tel"
            error={phoneErr}
          />
          {/* Summary */}
          <div style={{...S.card,marginTop:10,marginBottom:0}}>
            <p style={{fontSize:11,fontWeight:700,letterSpacing:1.2,textTransform:"uppercase",color:"#555",marginBottom:10}}>Order Summary</p>
            {[["Network",net?.name],["Data",pkg?.size],["Validity",pkg?.validity]].map(([l,v])=>(
              <div key={l} style={{display:"flex",justifyContent:"space-between",marginBottom:7}}>
                <span style={{fontSize:13,color:"#666"}}>{l}</span>
                <span style={{fontSize:13,fontWeight:600,color:"#e8e8f0"}}>{v}</span>
              </div>
            ))}
            <div style={{borderTop:"1px solid #1e1e30",paddingTop:9,marginTop:3,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontSize:13,color:"#aaa"}}>Total</span>
              <span style={{fontSize:19,fontWeight:900,fontFamily:"'Space Mono',monospace",color:"#00e0a0"}}>₵{pkg?.price.toFixed(2)}</span>
            </div>
          </div>
          <div style={S.warnBox}>⚠️ Double-check the number — transfers cannot be reversed.</div>
          <div style={{display:"flex",gap:10}}>
            <Btn style={S.secBtn} onClick={back}>← Back</Btn>
            <Btn style={{...S.primBtn,flex:1}} onClick={()=>{if(okPhone())next();}}>Continue</Btn>
          </div>
        </div>
      )}

      {/* ── Step 3: Payment ── */}
      {step===3 && (
        <div style={{animation:"fsUp 0.27s ease"}}>
          <h2 style={S.h2}>Payment</h2>

          {/* Method tabs */}
          <div style={{display:"flex",gap:10,marginBottom:20}}>
            {[{id:"momo",icon:"📱",l:"Mobile Money"},{id:"card",icon:"💳",l:"Debit/Credit"}].map(m=>(
              <Btn key={m.id}
                style={{flex:1,borderRadius:12,padding:"13px 10px",display:"flex",flexDirection:"column",alignItems:"center",gap:5,
                  border:`2px solid ${pay===m.id?"#00e0a0":"#1e1e30"}`,
                  background:pay===m.id?"#00e0a010":"#0f0f1c",
                }}
                onClick={()=>{setPay(m.id);setPayErr("");}}>
                <span style={{fontSize:22}}>{m.icon}</span>
                <span style={{fontSize:12,fontWeight:600,color:pay===m.id?"#00e0a0":"#888"}}>{m.l}</span>
              </Btn>
            ))}
          </div>

          {/* MoMo */}
          {pay==="momo" && (
            <Field
              label="📱 MoMo Number"
              prefix="🇬🇭 +233"
              value={momo}
              onChange={e=>{setMomo(fmtPhone(e.target.value));setPayErr("");}}
              placeholder="XX XXX XXXX"
              maxLen={12}
              type="tel"
              inputMode="tel"
              hint="MTN, Telecel or AT MoMo number"
            />
          )}

          {/* Card */}
          {pay==="card" && (
            <>
              <Field
                label="💳 Card Number"
                value={card}
                onChange={e=>{setCard(fmtCard(e.target.value));setPayErr("");}}
                placeholder="XXXX XXXX XXXX XXXX"
                maxLen={19}
                inputMode="numeric"
              />
              <div style={{display:"flex",gap:10,marginTop:-6}}>
                <div style={{flex:1}}>
                  <Field
                    label="Expiry"
                    value={exp}
                    onChange={e=>{setExp(fmtExp(e.target.value));setPayErr("");}}
                    placeholder="MM/YY"
                    maxLen={5}
                    inputMode="numeric"
                  />
                </div>
                <div style={{flex:1}}>
                  <Field
                    label="CVV"
                    value={cvv}
                    onChange={e=>{setCvv(e.target.value.replace(/\D/g,"").slice(0,4));setPayErr("");}}
                    placeholder="123"
                    maxLen={4}
                    type="password"
                    inputMode="numeric"
                  />
                </div>
              </div>
            </>
          )}

          {payErr && <p style={{...S.errTxt,marginBottom:12}}>{payErr}</p>}

          {/* Final chip */}
          <div style={{background:"linear-gradient(135deg,#0f1a14,#0a141a)",border:"1px solid #00e0a030",borderRadius:14,padding:"15px 17px",marginBottom:20,marginTop:6}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <p style={{fontSize:11,color:"#888",margin:"0 0 3px"}}>You're paying</p>
                <p style={{fontSize:25,fontWeight:900,fontFamily:"'Space Mono',monospace",color:"#00e0a0",margin:0}}>₵{pkg?.price.toFixed(2)}</p>
              </div>
              <div style={{textAlign:"right"}}>
                <p style={{fontSize:13,fontWeight:600,color:"#e8e8f0",margin:"0 0 3px"}}>{net?.name} · {pkg?.size}</p>
                <p style={{fontSize:12,color:"#888",margin:0}}>→ {phone||"—"}</p>
              </div>
            </div>
          </div>

          <div style={{display:"flex",gap:10}}>
            <Btn style={S.secBtn} disabled={busy} onClick={back}>← Back</Btn>
            <Btn
              style={{...S.primBtn,flex:1,opacity:busy?0.7:1,background:busy?"#1a1a2e":"linear-gradient(135deg,#00e0a0,#00b8d4)"}}
              disabled={busy}
              onClick={handlePay}>
              {busy
                ? <span style={{display:"flex",alignItems:"center",gap:8}}><Spin size={16} color="#888"/> Processing…</span>
                : "🔒 Pay Now"}
            </Btn>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══ BALANCE ═══ */
function BalancePage() {
  const [selId,  setSelId]  = useState("mtn");
  const [loading,setLoading]= useState(false);
  const [ts,     setTs]     = useState(nowTime());
  const [key,    setKey]    = useState(0);
  const [bals,   setBals]   = useState(
    ()=>Object.fromEntries(Object.entries(BASE_BAL).map(([k,v])=>[k,{...v}]))
  );

  const refresh = useCallback(async(silent=false)=>{
    if(!silent) setLoading(true);
    await new Promise(r=>setTimeout(r,silent?700:1600));
    setBals(prev=>{
      const n={...prev};
      Object.keys(n).forEach(id=>{
        const nudge = parseFloat((Math.random()*0.07).toFixed(2));
        n[id]={...n[id], used: Math.min(n[id].total, parseFloat((n[id].used+nudge).toFixed(2)))};
      });
      return n;
    });
    setTs(nowTime());
    setKey(k=>k+1);
    if(!silent) setLoading(false);
  },[]);

  useEffect(()=>{
    const id=setInterval(()=>refresh(true),30000);
    return ()=>clearInterval(id);
  },[refresh]);

  const bal  = bals[selId];
  const net  = netById(selId);
  const pct  = Math.round(((bal.total-bal.used)/bal.total)*100);
  const rClr = pct>50?"#00e0a0":pct>25?"#FFD000":"#ff4444";

  return (
    <div style={S.pg}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
        <h2 style={{...S.h2,margin:0}}>Data Balance</h2>
        <Btn style={S.icoBtn} onClick={()=>refresh(false)} disabled={loading}>
          {loading
            ? <Spin size={15} color="#00e0a0"/>
            : <span style={{fontSize:18,lineHeight:1}}>🔄</span>}
        </Btn>
      </div>

      {/* Live pill */}
      <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:14,padding:"8px 12px",background:"#00e0a010",border:"1px solid #00e0a030",borderRadius:10}}>
        <span style={{width:8,height:8,borderRadius:"50%",background:"#00e0a0",flexShrink:0,animation:"pulse 1.4s infinite"}}/>
        <span style={{fontSize:12,color:"#00e0a0",fontWeight:700}}>Live Feed</span>
        <span style={{marginLeft:"auto",fontSize:11,color:"#555",fontFamily:"'Space Mono',monospace"}}>Updated {ts}</span>
      </div>

      {/* Network tabs */}
      <div style={{display:"flex",gap:7,marginBottom:16}}>
        {NETWORKS.map(n=>(
          <Btn key={n.id}
            style={{flex:1,borderRadius:11,padding:"9px 4px",display:"flex",flexDirection:"column",alignItems:"center",gap:4,
              border:`2px solid ${selId===n.id?"#00e0a0":"#1e1e30"}`,
              background:selId===n.id?"#00e0a010":"#0f0f1c",
            }}
            onClick={()=>{setSelId(n.id);setKey(k=>k+1);}}>
            <span style={{width:28,height:28,borderRadius:7,background:n.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:900,color:n.textColor}}>
              {n.logo}
            </span>
            <span style={{fontSize:9,fontWeight:600,color:selId===n.id?"#00e0a0":"#666"}}>{n.shortName}</span>
          </Btn>
        ))}
      </div>

      {/* Main card */}
      <div key={`card-${selId}-${key}`}
        style={{...S.card,border:`2px solid ${net.solid}33`,padding:0,overflow:"hidden",marginBottom:10,animation:"fsUp 0.32s ease"}}>
        <div style={{background:net.gradient,padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <p style={{margin:0,fontSize:15,fontWeight:800,color:net.textColor}}>{net.name}</p>
            <p style={{margin:0,fontSize:11,color:net.textColor,opacity:0.7}}>{bal.type}</p>
          </div>
          <div style={{textAlign:"right",color:net.textColor}}>
            <p style={{margin:0,fontSize:10,opacity:0.7}}>Expires</p>
            <p style={{margin:0,fontSize:12,fontWeight:700}}>{bal.expiry}</p>
          </div>
        </div>
        <div style={{padding:"20px",display:"flex",gap:20,alignItems:"center",justifyContent:"center"}}>
          <div style={{position:"relative",flexShrink:0}}>
            <Ring pct={pct} color={rClr} size={138}/>
            <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",textAlign:"center",pointerEvents:"none"}}>
              <p style={{margin:0,fontSize:23,fontWeight:900,fontFamily:"'Space Mono',monospace",color:"#f0f0ff",lineHeight:1}}>
                {(bal.total-bal.used).toFixed(1)}
              </p>
              <p style={{margin:0,fontSize:11,color:rClr,fontWeight:700}}>{bal.unit}</p>
              <p style={{margin:0,fontSize:9,color:"#777"}}>remaining</p>
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            {[
              {l:"Total",v:`${bal.total}${bal.unit}`,  c:"#e8e8f0"},
              {l:"Used", v:`${bal.used}${bal.unit}`,   c:"#ff6b6b"},
              {l:"Left", v:`${pct}%`,                  c:rClr},
            ].map(s=>(
              <div key={s.l} style={{textAlign:"center"}}>
                <p style={{margin:0,fontSize:17,fontWeight:800,fontFamily:"'Space Mono',monospace",color:s.c}}>{s.v}</p>
                <p style={{margin:0,fontSize:9,color:"#555",textTransform:"uppercase",letterSpacing:1}}>{s.l}</p>
              </div>
            ))}
          </div>
        </div>
        <div style={{margin:"0 18px 5px",height:5,background:"#1e1e30",borderRadius:3,overflow:"hidden"}}>
          <div style={{width:`${100-pct}%`,height:"100%",background:rClr,borderRadius:3,transition:"width 1.1s cubic-bezier(.4,0,.2,1)"}}/>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",padding:"3px 18px 15px"}}>
          <span style={{fontSize:10,color:"#555"}}>{bal.used}{bal.unit} used</span>
          <span style={{fontSize:10,color:"#555"}}>{bal.total}{bal.unit} total</span>
        </div>
      </div>

      {/* Mini overview */}
      <p style={{...S.secLabel,marginTop:18}}>All Networks</p>
      {NETWORKS.map(n=>{
        const b = bals[n.id];
        const p = Math.round(((b.total-b.used)/b.total)*100);
        const c = p>50?"#00e0a0":p>25?"#FFD000":"#ff4444";
        return (
          <Btn key={n.id}
            style={{...S.rCard,width:"100%",textAlign:"left",marginBottom:8,display:"flex"}}
            onClick={()=>{setSelId(n.id);setKey(k=>k+1);}}>
            <span style={{width:36,height:36,borderRadius:10,background:n.gradient,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:900,color:n.textColor,flexShrink:0}}>
              {n.logo}
            </span>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:13,fontWeight:600,color:"#e8e8f0"}}>{n.name}</span>
                <span style={{fontSize:12,color:c,fontWeight:700}}>{(b.total-b.used).toFixed(1)}{b.unit}</span>
              </div>
              <div style={{height:5,background:"#1a1a2e",borderRadius:3,overflow:"hidden"}}>
                <div style={{width:`${100-p}%`,height:"100%",background:n.gradient,borderRadius:3,transition:"width 1s ease"}}/>
              </div>
            </div>
          </Btn>
        );
      })}
    </div>
  );
}

/* ═══ HISTORY ═══ */
function HistoryPage() {
  const { history } = useCtx();
  const all = [...history, ...SEED_HISTORY];

  return (
    <div style={S.pg}>
      <h2 style={S.h2}>Transactions</h2>
      <p style={{color:"#666",fontSize:13,marginBottom:18,marginTop:-12}}>{all.length} orders total</p>
      {all.map((o,i)=>{
        const n = netById(o.networkId);
        return (
          <div key={i}
            style={{...S.rCard,marginBottom:10,animation:`fsUp 0.35s ${Math.min(i*0.04,0.3)}s ease both`}}>
            <div style={{width:44,height:44,borderRadius:12,background:n?.gradient||"#333",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:900,color:n?.textColor||"#fff",flexShrink:0}}>
              {n?.logo||"?"}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <p style={{margin:0,fontSize:14,fontWeight:600,color:"#e8e8f0"}}>{n?.name} · {o.size}</p>
              <p style={{margin:"3px 0 0",fontSize:12,color:"#666"}}>{o.phone}</p>
              <p style={{margin:"2px 0 0",fontSize:11,color:"#444"}}>{o.date}</p>
            </div>
            <div style={{textAlign:"right",flexShrink:0}}>
              <p style={{margin:"0 0 4px",fontSize:14,fontWeight:700,color:"#00e0a0",fontFamily:"'Space Mono',monospace"}}>₵{o.price.toFixed(2)}</p>
              <span style={S.badge}>✓ delivered</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ═══ SETTINGS ═══ */
const stgRef = {notif:true,autoRefresh:true,history:true,dark:true};

function SettingsPage() {
  const [s,setS]=useState({...stgRef});
  const tog = k => { const n={...s,[k]:!s[k]}; Object.assign(stgRef,n); setS(n); };

  const Tog = ({k}) => (
    <div onClick={()=>tog(k)}
      style={{width:46,height:26,borderRadius:13,background:s[k]?"#00e0a0":"#1e1e30",position:"relative",cursor:"pointer",transition:"background 0.28s",flexShrink:0,WebkitTapHighlightColor:"transparent"}}>
      <div style={{position:"absolute",top:3,width:20,height:20,borderRadius:"50%",background:"#fff",left:s[k]?23:3,transition:"left 0.28s cubic-bezier(.34,1.56,.64,1)",boxShadow:"0 1px 4px #0007"}}/>
    </div>
  );

  return (
    <div style={S.pg}>
      <h2 style={S.h2}>Settings</h2>
      <div style={{...S.card,padding:0,overflow:"hidden",marginBottom:14}}>
        {[
          {k:"notif",      i:"🔔",l:"Push Notifications",  s:"Get alerts on delivery"},
          {k:"autoRefresh",i:"🔄",l:"Auto-refresh Balance", s:"Every 30 seconds"},
          {k:"history",    i:"📋",l:"Save History",          s:"Keep purchase records"},
          {k:"dark",       i:"🌙",l:"Dark Mode",             s:"Always on"},
        ].map((row,i,arr)=>(
          <div key={row.k}
            style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 16px",borderBottom:i<arr.length-1?"1px solid #1a1a2e":"none"}}>
            <div>
              <p style={{margin:0,fontSize:14,fontWeight:600,color:"#e8e8f0"}}>{row.i} {row.l}</p>
              <p style={{margin:"3px 0 0",fontSize:12,color:"#666"}}>{row.s}</p>
            </div>
            <Tog k={row.k}/>
          </div>
        ))}
      </div>
      <div style={{...S.card,padding:0,overflow:"hidden",marginBottom:14}}>
        {[
          {l:"Version",    v:"1.0.0"},
          {l:"Framework",  v:"React + Capacitor"},
          {l:"Platform",   v:"iOS & Android"},
          {l:"Data Source",v:"BestDealsGH"},
        ].map((r,i,arr)=>(
          <div key={r.l}
            style={{display:"flex",justifyContent:"space-between",padding:"13px 16px",borderBottom:i<arr.length-1?"1px solid #1a1a2e":"none"}}>
            <span style={{fontSize:13,color:"#777"}}>{r.l}</span>
            <span style={{fontSize:13,fontWeight:600,color:"#e8e8f0"}}>{r.v}</span>
          </div>
        ))}
      </div>
      <p style={{textAlign:"center",fontSize:11,color:"#333",marginTop:16}}>
        Powered by BestDealsGH · Made for Ghana 🇬🇭
      </p>
    </div>
  );
}

/* ═══ BOTTOM NAV ═══ */
const TABS = [
  {id:"home",    icon:"🏠",l:"Home"},
  {id:"buy",     icon:"⚡",l:"Buy"},
  {id:"balance", icon:"📊",l:"Balance"},
  {id:"history", icon:"🕑",l:"History"},
  {id:"settings",icon:"⚙️",l:"Settings"},
];

function BottomNav({ page, setPage }) {
  return (
    <nav style={{
      position:"sticky",bottom:0,
      background:"rgba(8,8,15,0.97)",
      backdropFilter:"blur(24px)",
      WebkitBackdropFilter:"blur(24px)",
      borderTop:"1px solid #111122",
      display:"flex",
      paddingBottom:"env(safe-area-inset-bottom,0px)",
      zIndex:200,
      flexShrink:0,
    }}>
      {TABS.map(t=>{
        const on = page===t.id;
        return (
          <Btn key={t.id}
            style={{flex:1,background:"none",border:"none",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:2,padding:"10px 2px 8px",position:"relative"}}
            onClick={()=>setPage(t.id)}>
            {on && (
              <div style={{position:"absolute",top:0,left:"50%",transform:"translateX(-50%)",width:22,height:3,background:"#00e0a0",borderRadius:"0 0 4px 4px",animation:"slideDown 0.2s ease"}}/>
            )}
            <span style={{
              fontSize: on?24:20,
              display:"block",
              filter: on?"none":"grayscale(1) opacity(0.38)",
              transform: on?"translateY(-1px)":"none",
              transition:"all 0.22s cubic-bezier(.34,1.56,.64,1)",
              lineHeight:1,
            }}>{t.icon}</span>
            <span style={{
              fontSize:9,display:"block",letterSpacing:0.3,
              color: on?"#00e0a0":"#444",
              fontWeight: on?700:400,
              transition:"color 0.2s",
            }}>{t.l}</span>
          </Btn>
        );
      })}
    </nav>
  );
}

/* ═══ STATUS BAR ═══ */
function StatusBar() {
  const [t,setT] = useState(nowTime());
  useEffect(()=>{
    const id=setInterval(()=>setT(nowTime()),1000);
    return ()=>clearInterval(id);
  },[]);
  return (
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 18px 7px",borderBottom:"1px solid #0e0e1e",flexShrink:0}}>
      <span style={{fontSize:13,fontWeight:800,fontFamily:"'Space Mono',monospace",color:"#00e0a0",letterSpacing:-0.5}}>⚡ DataBridge</span>
      <div style={{display:"flex",alignItems:"center",gap:7}}>
        <span style={{width:7,height:7,borderRadius:"50%",background:"#00e0a0",animation:"pulse 1.5s infinite"}}/>
        <span style={{fontSize:11,color:"#555",fontFamily:"'Space Mono',monospace"}}>{t}</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOT
// ─────────────────────────────────────────────────────────────────────────────
export default function App() {
  const [page,      setPage]      = useState("home");
  const [preselect, setPreselect] = useState(null);
  const [history,   setHistory]   = useState([]);

  const addOrder = useCallback(o => setHistory(h=>[o,...h]),[]);

  return (
    <Ctx.Provider value={{ history, addOrder }}>
      <style>{CSS}</style>
      <div style={{minHeight:"100vh",background:"#060610",display:"flex",justifyContent:"center"}}>
        <div style={{
          width:"100%",maxWidth:480,minHeight:"100vh",
          background:"#0a0a14",
          display:"flex",flexDirection:"column",
          boxShadow:"0 0 80px #00000077",
          fontFamily:"'DM Sans',sans-serif",
        }}>
          <StatusBar/>
          <div key={page} style={{
            flex:1,
            overflowY:"auto",
            overflowX:"hidden",
            WebkitOverflowScrolling:"touch",
          }}>
            {page==="home"    && <HomePage setPage={setPage} setPreselect={setPreselect}/>}
            {page==="buy"     && <BuyPage preselect={preselect} clearPreselect={()=>setPreselect(null)}/>}
            {page==="balance" && <BalancePage/>}
            {page==="history" && <HistoryPage/>}
            {page==="settings"&& <SettingsPage/>}
          </div>
          <BottomNav page={page} setPage={setPage}/>
        </div>
      </div>
    </Ctx.Provider>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STYLES
// ─────────────────────────────────────────────────────────────────────────────
const S = {
  pg:{ padding:"14px 16px 28px" },
  h2:{ fontSize:21,fontWeight:900,fontFamily:"'Space Mono',monospace",color:"#f0f0ff",margin:"0 0 16px" },

  hero:{ background:"linear-gradient(145deg,#0d0d20,#111130)",borderRadius:18,padding:"26px 22px 28px",marginBottom:20,position:"relative",overflow:"hidden",border:"1px solid #1a1a30" },
  heroBg:{ position:"absolute",inset:0,background:"radial-gradient(ellipse at 80% 0%,#FFD00012,transparent 65%)",pointerEvents:"none" },
  heroCta:{ background:"linear-gradient(135deg,#00e0a0,#00b8d4)",border:"none",color:"#0a0a14",padding:"12px 22px",borderRadius:12,fontSize:14,fontWeight:800 },

  secLabel:{ fontSize:11,fontWeight:700,letterSpacing:1.5,textTransform:"uppercase",color:"#555",marginBottom:12,display:"block" },
  seeAll:{ background:"none",border:"none",color:"#00e0a0",fontSize:12,padding:0 },

  qBtn:{ background:"#0f0f1c",border:"1px solid #1a1a2e",borderRadius:14,padding:"12px 6px",display:"flex",flexDirection:"column",alignItems:"center",gap:6 },

  netChip:{ background:"#0f0f1c",border:"1px solid #1a1a2e",borderRadius:20,padding:"7px 11px",display:"flex",alignItems:"center",gap:7,flexShrink:0 },

  rCard:{ background:"#0f0f1c",border:"1px solid #1a1a2e",borderRadius:14,padding:"12px 14px",display:"flex",alignItems:"center",gap:12 },
  badge:{ fontSize:10,color:"#00e0a0",background:"#00e0a015",borderRadius:20,padding:"2px 7px",whiteSpace:"nowrap" },
  emptyBox:{ background:"#0f0f1c",border:"1px solid #1a1a2e",borderRadius:14,padding:"28px 20px",textAlign:"center" },

  card:{ background:"#0f0f1c",border:"1px solid #1a1a2e",borderRadius:16,padding:"15px" },

  nCard:{ borderRadius:16,padding:"18px 10px",display:"flex",flexDirection:"column",alignItems:"center",gap:0,position:"relative",transition:"border-color 0.2s" },
  pCard:{ borderRadius:12,padding:"12px 6px",display:"flex",flexDirection:"column",alignItems:"center",gap:0,position:"relative",transition:"border-color 0.2s" },
  bestTag:{ position:"absolute",top:-7,left:"50%",transform:"translateX(-50%)",background:"#FFD000",color:"#1a0a00",fontSize:8,fontWeight:900,padding:"2px 6px",borderRadius:20,whiteSpace:"nowrap" },

  warnBox:{ fontSize:12,color:"#ff9944",background:"#ff994412",border:"1px solid #ff994430",borderRadius:8,padding:"10px 13px",margin:"12px 0 18px" },

  lbl:{ fontSize:12,color:"#888",marginBottom:5,fontWeight:600,display:"block" },
  inputBox:{ background:"#0f0f1c",border:"1.5px solid",borderRadius:12,display:"flex",alignItems:"center",overflow:"hidden",marginBottom:4 },
  pfx:{ padding:"0 12px",fontSize:13,borderRight:"1.5px solid #1e1e30",lineHeight:"50px",color:"#888",whiteSpace:"nowrap",flexShrink:0 },
  inp:{ flex:1,background:"none",border:"none",outline:"none",color:"#f0f0ff",padding:"14px 14px",fontFamily:"'DM Sans',sans-serif",width:"100%",minWidth:0 },
  errTxt:{ fontSize:12,color:"#ff5050",margin:"2px 0 10px" },
  hintTxt:{ fontSize:11,color:"#555",margin:"2px 0 12px" },

  primBtn:{ flex:1,background:"linear-gradient(135deg,#00e0a0,#00b8d4)",color:"#0a0a14",border:"none",borderRadius:14,padding:"15px",fontSize:15,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",gap:8 },
  secBtn:{ background:"none",border:"1.5px solid #1e1e30",color:"#888",borderRadius:14,padding:"15px 16px",fontSize:14,flexShrink:0 },
  icoBtn:{ background:"#0f0f1c",border:"1.5px solid #1e1e30",borderRadius:10,padding:"8px 10px",display:"flex",alignItems:"center",justifyContent:"center",minWidth:38,minHeight:38 },
};

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900&display=swap');
  *, *::before, *::after { box-sizing:border-box; }
  html, body { margin:0; padding:0; background:#060610; -webkit-text-size-adjust:100%; overscroll-behavior:none; }
  button { cursor:pointer; font-family:'DM Sans',sans-serif; border:none; background:none; }
  input  { font-family:'DM Sans',sans-serif; }
  input::placeholder { color:#2e2e40; }
  p { margin:0; }
  ::-webkit-scrollbar { width:3px; height:3px; }
  ::-webkit-scrollbar-track { background:#0a0a14; }
  ::-webkit-scrollbar-thumb { background:#1e1e30; border-radius:2px; }

  @keyframes fsUp  { from{opacity:0;transform:translateY(13px);}to{opacity:1;transform:translateY(0);} }
  @keyframes spin  { to{transform:rotate(360deg);} }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1);}50%{opacity:0.4;transform:scale(0.78);} }
  @keyframes rpl   { to{transform:translate(-50%,-50%) scale(32);opacity:0;} }
  @keyframes popIn { from{opacity:0;transform:scale(0.45);}to{opacity:1;transform:scale(1);} }
  @keyframes drawC { to{stroke-dashoffset:0;} }
  @keyframes drawK { to{stroke-dashoffset:0;} }
  @keyframes slideDown { from{opacity:0;transform:translateX(-50%) scaleX(0);}to{opacity:1;transform:translateX(-50%) scaleX(1);} }
`;
